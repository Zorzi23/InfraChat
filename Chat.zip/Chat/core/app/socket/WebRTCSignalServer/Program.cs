using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WebRTCSignalServer.Handlers;
using WebRTCSignalServer.Helper;
using WebRTCSignalServer.Middleware;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<WebSocketHandler>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseWebSockets();

app.UseMiddleware<WebSocketMiddleware>();

app.UseRouting();

app.Run($"http://{NetworkHelper.GetLocalIPAddress() ?? "localhost"}:2308");
// app.Run();
