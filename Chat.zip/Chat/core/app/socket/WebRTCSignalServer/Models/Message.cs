namespace WebRTCSignalServer.Models
{
    public class Message
    {
        public string Type { get; set; }
        public string Data { get; set; }
    }
}
