using System.Net;
using System.Net.Sockets;

namespace WebRTCSignalServer.Helper
{

    public static class NetworkHelper
    {
        public static string GetLocalIPAddress()
        {
            var hostName = Dns.GetHostName();
            var ipHostEntry = Dns.GetHostEntry(hostName);

            foreach (var ipAddress in ipHostEntry.AddressList)
            {
                if (ipAddress.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ipAddress.ToString();
                }
            }

            return null;
        }
    }
}

