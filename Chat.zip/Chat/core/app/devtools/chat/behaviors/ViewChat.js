
class ViewChat {

    #oChatConnection;

    #oElements = {};

    constructor() {
        this.#setChatConnection(new SocketConnection());
    }

    #setChatConnection(oChatConnection) {
        this.#oChatConnection = oChatConnection;
        return this;
    }

    getChatConnection() {
        return this.#oChatConnection;
    }

    /**
     * 
     * @param {Object<HTMLElement>} oElements 
     * @returns {ViewChat}
     */
    #setElements(oElements) {
        this.#oElements = oElements;
        return this;
    }

    /**
     * 
     * @returns {Object<HTMLElement>}
     */
    getElements() {
        return this.#oElements;
    }

    /**
     * 
     * @param {Message} oMessage 
     */
    addEnterUserMessage(oMessage) {
        const oMessageBox = this.#createEnterUserMessageBox(oMessage.getData());
        this.#renderMessage(oMessageBox);
        return this;
    }

    /**
     * 
     * @param {Message} oMessage 
     */
    addExitUserMessage(oMessage) {
        const oMessageBox = this.#createExitUserMessageBox(oMessage.getData());
        this.#renderMessage(oMessageBox);
        return this;
    }

    #isEnterKey(iEventKey) {
        return iEventKey === 13;
    }

    #isValidIp(sIp) {
        return this.#getIpv4Regex().test(sIp) 
            || this.#getIpv6Regex().test(sIp)
            || /localhost/.test(sIp);
    }
    
    #getIpv4Regex() {
        return /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/;
    }
    
    #getIpv6Regex() {
        return /^([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)/;
    }

    /**
     * 
     * @returns {ViewChat}
     */
    load() {
        this.#mapElements().#treatBehaviors();
        return this;
    }

    /**
     * 
     * @returns {ViewChat}
     */
    remapElements() {
        return this.#mapElements();
    }

    /**
     * 
     * @returns {ViewChat}
     */
    #mapElements() {
        this.#setElements({
            oChatContainer: document.querySelector('.chat-container'),
            oChatSelfIp: document.querySelector('.self-ip-address-span'),
            oChatInputIp: document.querySelector('.chat-window-message-ip'),
            oChatInputMessage: document.querySelector('.chat-window-message')
        });
        return this;
    }

    #treatBehaviors() {
        this.#createSelfIpMarker();
        this.#createInputIpBehaviors();
        this.#createInputMessageBehaviors();
        return this;
    }

    async #createSelfIpMarker() {
       const {oChatSelfIp} = this.getElements();
       let sLocalIp = await WebRtcApi.captureLocalIp() || '';
       sLocalIp = sLocalIp.match(/.local/) ? 'Unreachable IP' : sLocalIp;
       oChatSelfIp.textContent = `Local IP Address: ${sLocalIp}`;
       return this;  
    }

    #createInputIpBehaviors() {
        const { oChatInputIp } = this.getElements();
        oChatInputIp.addEventListener('change', this.#onChangeInputIp.bind(this));
        oChatInputIp.addEventListener('keypress', this.#onKeyPressInputIp.bind(this));
        return this;
    }

    #onChangeInputIp() {
        this.getChatConnection().getSocket().close();
        return this;
    }

    #onKeyPressInputIp(oEvent) {
        if(!this.#isEnterKey(oEvent.keyCode)) {
            return this;
        }
        const oChatInputIp = oEvent.target;
        const sIp = oChatInputIp.value;
        if(!this.#isValidIp(sIp)) {
            alert('Invalid Ip Address!');
            return this;
        }
        this.#createSocketMessagesBehaviors(sIp);
        this.getElements().oChatInputMessage.focus();
        return this;
    }


    #createSocketMessagesBehaviors(sIp) {
        if(this.getChatConnection().isConnected()) {
            return this;
        }
        this.getChatConnection().connect(sIp);
        const oSocket = this.getChatConnection().getSocket();
        oSocket.onmessage = this.#onSocketReceiverMessage.bind(this);
        return this;
    }

    #onSocketReceiverMessage(oEvent) {
        const oMessage = (new Message())
            .setData(oEvent?.data);
        this.addExitUserMessage(oMessage);
        return this;
    }

    #createInputMessageBehaviors() {
        const { oChatInputMessage } = this.getElements();
        oChatInputMessage.addEventListener('keypress', this.#onKeyPressInputMessage.bind(this));
        return this;
    }

    #onKeyPressInputMessage(oEvent) {
        if(!this.#isEnterKey(oEvent.keyCode)) {
            return this;
        }
        const sIp = this.getElements().oChatInputIp?.value;
        if(!sIp) {
            alert('Please fill the IP input with an valid IPV4/IPV6 Address!');
            return this;
        }
        this.#createSocketMessagesBehaviors(sIp);
        if(!this.getChatConnection().isConnected()) {
            alert('⚠️ Socket user ureachable!');
            return this;
        }
        const oChatInputMessage = oEvent.target;
        const oMessage = (new Message())
            .setData(oChatInputMessage.value?.trim());
        this.addEnterUserMessage(oMessage);
        this.getChatConnection().getSocket().send(oMessage.getData());
        oChatInputMessage.value = null;
        return this;
    }

    /**
     * 
     * @param {HTMLElement} oMessageBox 
     * @returns {ViewChat}
     */
    #renderMessage(oMessageBox) {
        const { oChatContainer } = this.getElements();
        oChatContainer.appendChild(oMessageBox);
        return this;
    }

    /**
     * 
     * @param {String} sText 
     * @returns {HTMLElement}
     */
    #createEnterUserMessageBox(sText) {
        const oMessageBox = this.#createMessageBox(sText);
        oMessageBox.classList.add('chat-container-message-enter-user');
        return oMessageBox;
    }

    /**
     * 
     * @param {String} sText 
     * @returns {HTMLElement}
     */
    #createExitUserMessageBox(sText) {
        const oMessageBox = this.#createMessageBox(sText);
        oMessageBox.classList.add('chat-container-message-exit-user');
        return oMessageBox;
    }

    /**
     * 
     * @param {String} sText 
     * @returns {HTMLElement}
     */
    #createMessageBox(sText) {
        const oMessageBox = document.createElement('li');
        oMessageBox.textContent = sText;
        return oMessageBox;
    }

}

const oView = (new ViewChat()).load();