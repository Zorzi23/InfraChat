chrome.devtools.panels.create(
    "Chat",
    "icons/icon48.png",
    "core/app/devtools/chat/main.html",
    function(panel) {
      console.log("Chat panel added");
    }
);

class ArchitectPanels {

	#oBuilderPanels;

	createPanels() {

	}

}
  